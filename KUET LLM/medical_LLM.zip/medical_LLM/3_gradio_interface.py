import requests
import gradio as gr
def answer_generate(question,history):
    api="1234"
    r=requests.get(f"http://127.0.0.1:8000/medical/?ques={question}&api={api}")
    tt=r.json()["response"]
    return tt


questions=["tell me about diabetes","tell me about symptoms about diabetes","How does diabetes affect you?","What is normal sugar level by age in diabetes?","How diabetes is caused?","How to reduce blood sugar?"]
demo = gr.ChatInterface(fn=answer_generate, examples=questions, title="Diabetes LLM")
demo.launch(share=True)