from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    HfArgumentParser,
    TrainingArguments,
    pipeline,
    logging,
)
import os, torch
import os
import torch
from datasets import load_dataset, Dataset
import pandas as pd
import transformers
from transformers import AutoTokenizer
from trl import SFTTrainer
import transformers
from peft import AutoPeftModelForCausalLM
from transformers import GenerationConfig
from pynvml import *
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import FAISS
from langchain_community.document_loaders import TextLoader
from langchain_community.document_loaders import Docx2txtLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain import HuggingFacePipeline
from transformers.generation.utils import top_k_top_p_filtering
from transformers import pipeline


model_name = r"/home/sdm/notebooks/Models/merged_medical"

model = AutoModelForCausalLM.from_pretrained(
    model_name,
    # quantization_config=bnb_config,
    device_map="auto",
    trust_remote_code=True,
    attn_implementation="flash_attention_2",
    torch_dtype=torch.bfloat16,

)

tokenizer = AutoTokenizer.from_pretrained(model_name, trust_remote_code=True)

pipe = pipeline("text-generation",
                model=model,  # can also use the beta model
                tokenizer=tokenizer,
                # torch_dtype=torch.bfloat16,
                device_map="auto")
llm = HuggingFacePipeline(pipeline = pipe, model_kwargs = {'temperature':0})
# Doc file name for RAG
filename=r"/home/sdm/notebooks/Medical Data/Diabetes.docx"
model_name = "sentence-transformers/all-mpnet-base-v2"
def create_vectorstore(flag):
    if flag == False:
        loader = Docx2txtLoader(filename)
        documents=loader.load()
        text_splitter=CharacterTextSplitter(chunk_size=500,chunk_overlap=50,separator="\n")
        docs = text_splitter.split_documents(documents)
        hf = HuggingFaceEmbeddings(model_name=model_name)
        vectorstore=FAISS.from_documents(docs,hf)
        vectorstore.save_local('vectorstore')
        return vectorstore
    else:
        hf = HuggingFaceEmbeddings(model_name=model_name)
        new_vectorstore=FAISS.load_local("vectorstore",hf, allow_dangerous_deserialization=True)
        return new_vectorstore
if len(os.listdir("vectorstore"))==0:
    vectorstore=create_vectorstore(False)
else:
    vectorstore=create_vectorstore(True)

retriever=vectorstore.as_retriever()
from langchain import hub
prompt = hub.pull("rlm/rag-prompt")

def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
rag_chain = (
    {"context": retriever | format_docs, "question": RunnablePassthrough()}
    | prompt
    | llm
    | StrOutputParser()
)

def ans_ret(inp):
    ans=rag_chain.invoke(inp)   
    return ans


from fastapi import FastAPI
app = FastAPI()
@app.get("/")
def hello():
  return {"Hello world!"}
@app.get("/medical/")
def hello(ques:str="ques",api:str="123"):
    if str(api)=="1234":
        ans=ans_ret(ques)
        return ans
    else:
        return "Api key not matched!!!"

    